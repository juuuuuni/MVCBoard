package com.human.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.human.command.BCommand;
import com.human.command.BListCommand;


/**
 * Servlet implementation class BFrontController
 */
@WebServlet("*.do")
public class BFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo");
		request.setCharacterEncoding("utf-8");
		BCommand bCom=null;
		
		//사용자에게 보여줄 view 설정.
		String viewPage=null;
		String uri=request.getRequestURI();
		System.out.println(uri); //프로젝트/요청경로
		String conPath=request.getContextPath();
		System.out.println(conPath);//프로젝트
		String com=uri.substring(conPath.length());
		System.out.println(com);//  요청경로
		if(com.equals("/list.do")) { //list.do만 뽑아내기
			viewPage="list.jsp";
			bCom=new BListCommand();
			bCom.execute(request,response);
		}
		//
		RequestDispatcher dispatcher=
				request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
