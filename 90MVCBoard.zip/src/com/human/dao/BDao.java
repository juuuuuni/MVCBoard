package com.human.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.human.dto.BDto;
import com.human.util.DBConn;

public class BDao {
	public ArrayList<BDto> select(){
		  ArrayList<BDto> dtos=new ArrayList<BDto>();
		  
		  Connection con=DBConn.getConnection();
		  
		  String sql="select * from mvc_board order by bGroup desc,bStep asc";
		  Statement st=null;
		  ResultSet rs=null;
		  
		  try {
		   st=con.createStatement();
		   rs=st.executeQuery(sql);
		   while(rs.next()) {
		    dtos.add(new BDto(
		      rs.getInt("bId"),
		      rs.getInt("bHit"),
		      rs.getInt("bGroup"),
		      rs.getInt("bStep"),
		      rs.getInt("bIndent"),
		      rs.getString("bName"),
		      rs.getString("bTitle"),
		      rs.getString("bContent"),
		      rs.getDate("bDate")
		      )
		      );
		      
		   }
		   DBConn.close(st, rs);
		  } catch (Exception e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }
		  return dtos;
		 }

//
//	public ArrayList<BDto> select() {
//	ArrayList<BDto> dtos = new ArrayList<>();
//
//	Connection con = DBConn.getConnection();
//	String sql = "select * from mvc_board "
//	+"order by bGroup desc,bStep asc";
//	Statement st = null;
//	ResultSet rs = null;
//
//	try {
//		st = con.createStatement();
//		rs = st.executeQuery(sql);
//		while (rs.next()) {
//			//int bId, int bHit, int bGroup, int bStep, int bIndent,
//			//String bName, String bTitle, String bConent,
//			//Timestamp bDate
//			dtos.add(
//					new BDto(
//							rs.getInt("bId"),
//							rs.getInt("bHit"),
//							rs.getInt("bGroup"),
//							rs.getInt("bStep"),
//							rs.getInt("bIndent"),
//							rs.getString("bName"),
//							rs.getString("bTitle"),
//							rs.getString("bContent"),
//							rs.getTimestamp("bDate")
//							)
//					
//					);
//		}
//		DBConn.close(st, rs);
//	} catch (Exception e) {
//		e.printStackTrace();
//	}
//
//	return dtos;
//}

	public void insert(String bName, String bTitle, String bContent) {
		// TODO Auto-generated method stub
		Connection con = DBConn.getConnection();
		Statement st = null;

		try {
			st = con.createStatement();
			
			//insert into mvc_board(bId,bName,bTitle,bContent,bGroup,bStep,bIndent)
			//values (mvc_board_seq.nextval,'"+bName+"','"+bTitle+"','"+bContent+"',
			//    mvc_board_seq.currval,0,0);
			
			String sql = null;
			sql = String.format("insert into mvc_board(bId,bName,bTitle,bContent,bGroup,bStep,bIndent) "
			+ "values (mvc_board_seq.nextval,'"+bName+"','"+bTitle+"','"+bContent+"',"
			+"mvc_board_seq.currval,0,0)");
			System.out.println(sql);
			st.executeUpdate(sql);
			DBConn.close(st);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public BDto select(String bId) {
		  updateHit(bId);
		  BDto dto=null;
		  Connection con=DBConn.getConnection();
		  String sql;
		  sql=String.format("select * from mvc_board where bId=%s order by bGroup desc,bStep asc ",bId);
		  Statement st=null;
		  ResultSet rs=null;
		  
		  try {
		   st=con.createStatement();
		   rs=st.executeQuery(sql);
		   while(rs.next()) {
		    dto=new BDto(
		      rs.getInt("bId"),
		      rs.getInt("bHit"),
		      rs.getInt("bGroup"),
		      rs.getInt("bStep"),
		      rs.getInt("bIndent"),
		      rs.getString("bName"),
		      rs.getString("bTitle"),
		      rs.getString("bContent"),
		      rs.getTimestamp("bDate"));
		      
		   }
		   DBConn.close(st,rs);
		  } catch (Exception e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }
		  return dto;
		 }
//
//	public BDto select(String bId) {
//		updateHit(bId);
//		BDto dto=null;
//		Connection con = DBConn.getConnection();
//		String sql =String.format("select * from mvc_board "
//				+" where bId=%s "
//				+" order by bGroup desc,bStep asc"
//				,bId);
//		Statement st = null;
//		ResultSet rs = null;
//
//		try {
//			st = con.createStatement();
//			rs = st.executeQuery(sql);
//			while (rs.next()) {
//			
//				dto=new BDto(
//								rs.getInt("bId"),
//								rs.getInt("bHit"),
//								rs.getInt("bGroup"),
//								rs.getInt("bStep"),
//								rs.getInt("bIndent"),
//								rs.getString("bName"),
//								rs.getString("bTitle"),
//								rs.getString("bContent"),
//								rs.getTimestamp("bDate")
//								);
//						
//			
//			}
//			DBConn.close(st, rs);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return dto;
//	}

	private void updateHit(String bId) {
				Connection con = DBConn.getConnection();
				Statement st = null;

				try {
					st = con.createStatement();
					
					String sql = null;
					sql = String.format("update mvc_board "
					+"set bHit=bHit+1 "
					+"where bId=%s",bId);
					System.out.println(sql);
					st.executeUpdate(sql);
					DBConn.close(st);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}

	public void delete(String bId) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				Connection con = DBConn.getConnection();
				Statement st = null;

				try {
					st = con.createStatement();
					
					String sql = null;
					sql = String.format("delete mvc_board where bId=%s",bId);
					System.out.println(sql);
					st.executeUpdate(sql);
					DBConn.close(st);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

	public void update(String bId, String bTitle, String bContent) {
		// TODO Auto-generated method stub
		Connection con = DBConn.getConnection();
		Statement st = null;

		try {
			st = con.createStatement();
			
			String sql = null;
			sql = String.format("update mvc_board "
			+"set bContent='%s',bTitle='%s' "
			+"where bId=%s",bContent,bTitle,bId);
			System.out.println(sql);
			st.executeUpdate(sql);
			DBConn.close(st);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void reply(String bId, String bGroup, String bIndent, String bStep, String bName, String bTitle,
			String bContent) {
		//같은 그룹에 자기보다 큰스텝을 하나씩 증가하는
		// 작업을 한다.
		replyShape(bGroup,bStep);
		
		
		// TODO Auto-generated method stub
				Connection con = DBConn.getConnection();
				Statement st = null;

				try {
					st = con.createStatement();
					
		
					String sql = null;
					sql = String.format("insert into mvc_board(bId,bName,bTitle,bContent,bGroup,bStep,bIndent) "
							+ "values (mvc_board_seq.nextval,'"+bName+"','"
							+bTitle+"','"+bContent+"',"
							+"%s,%d,%d)"
						,bGroup
						,Integer.parseInt(bStep)+1
						,Integer.parseInt(bIndent)+1
					);
					System.out.println(sql);
					st.executeUpdate(sql);
					DBConn.close(st);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}

	private void replyShape(String bGroup, String bStep) {
		// bGroup중에서 bstep보다 큰 데이터들을 하나씩 증가시킨다.
		Connection con = DBConn.getConnection();
		PreparedStatement ps=null;

		try {
			
			String sql = null;
			sql = "update mvc_board "
			+"set bstep=bstep+1 "
			+"where bGroup=? and bstep > ?";
			System.out.println(sql);
			ps=con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(bGroup));
			ps.setInt(2, Integer.parseInt(bStep));
			
			ps.executeUpdate();
			DBConn.close(ps);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}










